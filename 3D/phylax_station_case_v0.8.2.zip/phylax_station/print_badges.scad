// PHYLAX badges for PC + monitor
// Shape: parts/badges.scad    Sizes: phylax_config.scad (section "badge_*")
// F5 = quick preview, F6 = full render, F7 = export STL.
// Tip: turn on Design > Automatic Reload and Preview, then edit the config in any editor and save.
include <phylax_config.scad>
include <lib/phylax_common.scad>
include <parts/badges.scad>

badge(badge_pc, 4.6); translate([0, badge_pc[1] + 5, 0]) badge(badge_mon, 6);
