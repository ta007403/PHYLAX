// Keyboard console base - print bottom down (open bottom). One piece: send to JLC (MJF/SLA) or a large-format printer.
// Shape: parts/console_base.scad    Sizes: phylax_config.scad (section "Keyboard console base")
// F5 = quick preview, F6 = full render, F7 = export STL.
// Tip: turn on Design > Automatic Reload and Preview, then edit the config in any editor and save.
include <phylax_config.scad>
include <lib/phylax_common.scad>
include <parts/console_base.scad>

translate([0,0,cb_H]) console_base();
