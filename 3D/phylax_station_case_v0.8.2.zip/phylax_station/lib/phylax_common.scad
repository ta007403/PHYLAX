// =====================================================================
//  PHYLAX Wallet Station - shared helpers used by several parts
//  (frames, panel ribs, drive-face, I/O shield, breakout and console helpers)
// =====================================================================
// =====================================================================

// ---------------------------------------------------------------- helpers
module rrect(s, r) {
    rr = max(0.01, min(r, min(s[0], s[1])/2 - 0.01));
    translate([rr, rr]) offset(r = rr) square([s[0] - 2*rr, s[1] - 2*rr]);
}
module rrect_c(s, r) translate(-s/2) rrect(s, r);

// rounded-rect slab, 45-degree chamfer on its top (+z) edge
module chamfer_slab(s, d, r, c) {
    hull() {
        linear_extrude(d - c) rrect(s, r);
        translate([c, c, 0]) linear_extrude(d) rrect([s[0] - 2*c, s[1] - 2*c], max(0.5, r - c));
    }
}

// vertical slot (2D) of length l, width w, starting at origin bottom
module vslot(l, w) hull() { translate([0, w/2]) circle(d = w); translate([0, l - w/2]) circle(d = w); }
module hslot(l, w) hull() { translate([w/2, 0]) circle(d = w); translate([l - w/2, 0]) circle(d = w); }

// rib Y ranges [y0, y1] that capture the front panel and the back plate
function rib_ys() = [
    [0, fp_y0 - 0.2],
    [fp_y1 + panel_clr, fp_y1 + panel_clr + rib_w],
    [bp_y0 - panel_clr - rib_w, bp_y0 - panel_clr],
    [bp_y1 + 0.2, pc_D]
];

// local frames -> world
module front_frame() translate([panel_x0, fp_y1, panel_z0]) rotate([90, 0, 0]) children();
module back_frame()  translate([panel_x0 + panel_w, bp_y0, panel_z0]) rotate([90, 0, 180]) children();
module mon_frame()   translate(mon_origin + [0, m_bd, 0]) rotate([90, 0, 0]) children();


// ---- shared between several parts ----
function bay_boss_pos() = [ [bay_x0 - 3.5, bay_y0 - 2], [bay_x1 + 3.5, bay_y0 - 2],
                            [bay_x0 - 3.5, bay_y1 + 2], [bay_x1 + 3.5, bay_y1 + 2] ];
dr_mid  = (bay_x0 + bay_x1)/2;
dr_fy0  = bay_y0 + clr;
dr_fy1  = bay_y1 - clr;
dr_zf   = fp_t - drive_face_proud;     // front of the faces
dr_zp   = -bay_boss_h;                  // front of the plate (against the bosses)
dr_pt   = 2.5;
front_usbc_c = [dr_mid + (bay_x1 - dr_mid)/2, dr_fy0 + 0.55*(dr_fy1 - dr_fy0)];
led_c   = [bay_x0 + clr + 9.5, dr_fy0 + 8];        // room for the bezel's nut inside the drive face
function front_usba_c(lx0, lx1) = [(lx0 + lx1)/2 + 3, dr_fy0 + 0.58*(dr_fy1 - dr_fy0)];
function shield_rect() = [rj45_c[0] - io_shield[0]/2, rj45_c[1] - io_shield[1]/2,
                          rj45_c[0] + io_shield[0]/2, rj45_c[1] + io_shield[1]/2];
function shield_screws() = let(r = shield_rect())
    [ [r[0] + 2.5, r[1] + 2.5], [r[2] - 2.5, r[1] + 2.5], [r[0] + 2.5, r[3] - 2.5], [r[2] - 2.5, r[3] - 2.5] ];

// --- USB-C breakout shelf (back-view local frame: x across, y up, z < 0 = into the case)
function bo_pcb_y0() = usbc_in_pos[1] - bo_socket_h - bo_pcb[2];      // PCB underside height
function bo_pcb_z1() = bp_t - bo_recess - bo_socket_out;               // PCB socket-side edge (local z)
function bo_hole_pos() = [ for (sx = [-1, 1], k = [0, 1])
    [usbc_in_pos[0] + sx*bo_holes[0]/2, bo_pcb_y0(), bo_pcb_z1() - bo_hole_edge - k*bo_holes[1]] ];
module badge(s, txt_size) {
    translate([0, 0, 0]) cube([s[0], s[1], badge_depth]);
    translate([s[0]/2, s[1]/2, badge_depth - 0.01])
        linear_extrude(0.6) text(badge_text, size = txt_size, font = badge_font, halign = "center", valign = "center");
}
kd_depth = kd_size[2] - kd_proud;          // pocket depth for the keyboard
tp_depth = tp_body[2] - tp_proud;
function kd_hole_pos() = [ for (sx = [-1, 1], sy = [-1, 1])
    [kd_p0[0] + kd_pocket[0]/2 + sx*kd_holes[0]/2, kd_p0[1] + kd_pocket[1]/2 + sy*kd_holes[1]/2] ];
module tp_pocket_2d() {
    rrect_c(tp_pocket, 3);
    rrect_c([tp_ear_spacing + tp_ear[0] + 2*cb_part_clr, tp_ear[1] + 2*cb_part_clr], 3);
}
