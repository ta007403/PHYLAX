// PC front panel - front face down
// Shape: parts/pc_front_panel.scad    Sizes: phylax_config.scad (section "Front panel layout")
// F5 = quick preview, F6 = full render, F7 = export STL.
// Tip: turn on Design > Automatic Reload and Preview, then edit the config in any editor and save.
include <phylax_config.scad>
include <lib/phylax_common.scad>
include <parts/pc_front_panel.scad>

translate([0,0,fp_t]) mirror([0,0,1]) pc_front_panel_local();
