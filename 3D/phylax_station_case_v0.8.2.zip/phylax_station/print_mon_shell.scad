// Monitor rear shell - back face down
// Shape: parts/mon_shell.scad    Sizes: phylax_config.scad (section "Monitor")
// F5 = quick preview, F6 = full render, F7 = export STL.
// Tip: turn on Design > Automatic Reload and Preview, then edit the config in any editor and save.
include <phylax_config.scad>
include <lib/phylax_common.scad>
include <parts/mon_shell.scad>

translate([0,0,m_L]) mon_shell_local();
