// PC drive insert (two drive faces) - print in black, front face down
// Shape: parts/pc_drive_insert.scad    Sizes: phylax_config.scad (section "Drive faces")
// F5 = quick preview, F6 = full render, F7 = export STL.
// Tip: turn on Design > Automatic Reload and Preview, then edit the config in any editor and save.
include <phylax_config.scad>
include <lib/phylax_common.scad>
include <parts/pc_drive_insert.scad>

translate([0,0,fp_t - drive_face_proud]) mirror([0,0,1]) pc_drive_insert_local();
