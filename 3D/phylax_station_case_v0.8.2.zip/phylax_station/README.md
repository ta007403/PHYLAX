# PHYLAX Wallet Station — retro case (v0.8.2)

A parametric OpenSCAD rebuild of a mini IBM 5150 + 5151 for the PHYLAX wallet station:
Raspberry Pi CM5 on the CM5 IO Board, a 7" CLB7INH touchscreen, a USB camera and a speaker.
The monitor bolts onto the PC as one block, and all cables between them run inside.

**Credits / license:** remix of *Mini IBM PC – working clone* by **alendian**
(https://www.thingiverse.com/thing:7253482), based on work by **giobbino (Giovanni Verrua)**
and earlier remixers. Released under **CC BY-SA 4.0**, the same license as the original.
The IBM badge is replaced by a PHYLAX badge.

## Files

```
phylax_config.scad        <- ALL sizes and positions (edit this)
print_<part>.scad         <- open one of these in OpenSCAD: F5 preview, F6 render, F7 export STL
parts/<part>.scad         <- the shape of each part, one file per part
lib/phylax_common.scad    <- small helpers shared by several parts
phylax_parts.scad         <- just includes every parts/ file (used by assembly.scad)
assembly.scad             <- everything together (fast or live mode, explode, show/hide groups)
stl_world/                <- ready-made meshes in assembled position, for the fast assembly view
make_world_stls.bat       <- double-click to refresh stl_world/ after changing the config (Windows)
world_part.scad           <- used by make_world_stls.bat
stl/                      <- rendered STLs from the current config
```

## How to edit

1. In OpenSCAD, open the `print_<part>.scad` you want, for example `print_pc_cover.scad`.
2. Turn on **Design → Automatic Reload and Preview**.
3. Open `phylax_config.scad` in OpenSCAD's editor or any text editor, change a value and save. The preview updates by itself.
4. **F6** renders and **F7** exports the STL.

**Why the sizes live in one file:** many parts must agree with each other. For example, the monitor bolt holes in the cover
must match the bosses in the monitor floor, and the hub posts must match the hub. One shared value updates every part that uses it.
Open `assembly.scad` after a change to check that everything still fits together.

**Assembly view speed:** `assembly.scad` starts in `mode = "fast"`. It loads the meshes in `stl_world/`, so it opens instantly and rotates smoothly.
After you change the config, double-click `make_world_stls.bat` (about 1 minute) and press F5 again.
Alternatively, set `mode = "live"`: it builds everything from the code, so the first F5 takes about 20–60 s, then it rotates smoothly.
Use the `show_*` switches at the top to show only the parts you're working on.
Previews (F5) use lighter circles; STL export (F6/F7) always uses full quality.

To change a **shape** (add a hole, move a vent pattern), edit that part's file in `parts/`.

## Parts to print

| Part | Qty | Colour | Orientation / notes |
|---|---|---|---|
| `pc_base` | 1 | beige | flat |
| `pc_cover` | 1 | beige | top on the bed; supports only for the switch window |
| `pc_front_panel` | 1 | beige | front face down |
| `pc_speaker_clamp` | 1 | any | flat; presses the speaker rim onto a 1.5 mm foam gasket, 2 × M3 × 8 (opposite corners) into the front panel |
| `pc_drive_insert` | 1 | black | front face down |
| `pc_back_plate` | 1 | beige | outside face down |
| `pc_io_shield` | 1 | grey/black | flat; holds the RJ45 panel jack, so a wrong cutout only costs this small plate |
| `pc_switch_plate` | 1 | beige | outside face down |
| `badges` | 1 | silver or 2-colour | two badges: PC + monitor |
| `mon_bezel` | 1 | beige | front face down (45° chamfer, no supports) |
| `mon_shell` | 1 | beige | back face down |
| `mon_display_clips` | 4 | any | flat; L-shaped, all 4 identical (flip 2 for the other side), 2 screws each into the bezel |
| `mon_knobs` | 2 | black | 100% infill |

Largest parts: base and cover are 200 × 150 mm, and the bezel and shell are 186 × 164 mm.

## Hardware

- Raspberry Pi CM5 (with Wi-Fi) + CM5 IO Board, plus a CM5 cooler
- **FPC ribbon cables with 90° ends** (ADT-Link style):
  - HDMI: IO board → display
  - USB-C: switched power lead → IO board
- **Small USB hub** inside the PC, for touch, camera, the front block port and one spare. It plugs into the inner USB3 port (drawing x = 93) through a 90° USB-A adapter
- Panel-mount USB-C female jacks ×2:
  - power inlet on the back
  - block-stack port in the floppy slot
- KCD3 red rocker switch (30 × 22 cutout). It cuts VBUS of the power lead; keep CC and GND connected.
- 40 mm round speaker + MAX98357A I2S amp, plus a 1.5 mm craft-foam ring as gasket (40 mm OD, 32 mm ID)
- 5 mm green LED + resistor, in a 5 mm chrome LED bezel with nut (8 mm panel hole)
- 4 rubber feet (12 mm)
- Screws and inserts:
  - M3 heat-set inserts ×8 (4 cover pillars, 4 monitor floor)
  - M3 ×8 countersunk ×4: base → cover
  - M3 ×10 ×4: cover → monitor (from inside the PC)
  - M3 ×8 countersunk ×4: shell → bezel lip (sides)
  - M3 ×6 ×12: 4 into the display's brass poles, 8 into the bezel wall posts (2 per clip)
  - M2.5 self-tapping, short ×14: IO board ×4, drive insert ×4, I/O shield ×4, MAX98357A amp ×2
  - M2 self-tapping, short ×8: switch plate ×4, camera ×4

## Assembly order

1. Press the inserts into the cover pillars and the monitor floor bosses.
2. **Monitor:**
   - Put the display face-down into the bezel.
   - Screw the 4 clips onto the brass standoffs and the bezel posts.
   - Mount the camera on its 4 posts.
   - Slide the shell over the bezel lip and fix it with the 4 side screws.
3. Bolt the monitor onto the cover from inside, and route the FPC ribbons and USB cables down through the cable slot.
4. Mount the IO board on the base standoffs, then fit the hub, amp and wiring.
5. **Front panel:** fit the speaker and the drive insert (LED, front USB-C), then stand the panel in the base's front channel.
6. **Back plate:** fit the I/O shield and the USB-C power inlet, then stand the plate in the back channel.
7. Lower the cover over everything; the ribs capture both panels. Screw it on from below with 4 countersunk M3 screws.

## Values to measure before printing (`// MEASURE` in the config)

| Value | Why |
|---|---|
| `io_holes_drawing` | Set from the official drawing. The right-hand pair (x = 132.5) isn't dimensioned there, so check it on the board |
| `usbc_ear_spacing`, `front_usbc_ear_spacing` | Screw spacing of your panel-mount USB-C jacks |
| `cam_holes`, `cam_lens_h` | Camera hole spacing and lens height (lens height changes with focus) |
| `switch_cut` | Check against your KCD3 |

**Tip:** print `pc_io_shield`, a slice of the front panel, and one display clip first. They're quick and check the fits.

## Backlog

- **Built-in keyboard (3-in-1 carry unit):** integrate the mini keyboard
  (AliExpress item 1005005065834311) into the PC case, so the PC, monitor and keyboard become one unit that's easy to carry.
  Needs the keyboard's dimensions and a decision on mounting (slide-out tray, fold-down front, or a clip-on lid).
- Optional: a functional knob (EC11 encoder for volume, or a pot on the display's Backlight CTR header).

## Port layout (v0.4)

| Where | Port | Part | Connects to |
|---|---|---|---|
| Front, left drive face | USB-A | panel-mount PCB jack 31.2 × 10.2, holes Ø3 at 25 mm | hub |
| Front, floppy slot | USB-C | Adafruit 4053 (ears 20 mm, M3) | hub |
| Back | USB-C power | USB-C pass-through breakout (36 × 20 mm, holes 28 × 14, M2) on a shelf behind the back plate | VCC via the red switch; short 90° USB-C extension → IO board USB-C |
| Back, I/O shield | RJ45 | panel-mount jack, ears 28 mm, 90° plug | IO board RJ45 |
| Inside | touch, camera | hub USB2 / USB3 (face the cable slot) | from the monitor |
| Inside | keyboard | IO board USB3 (x 121.25) | for the built-in keyboard later |

- **USB hub:** 65 × 30 mm, 4 × USB-A, holes 58 × 23 mm. It hangs upside down under the cover top on 4 posts (M2.5).
  Its upstream connection isn't confirmed yet; check what's on the back of the board.
- The IO board sits 22 mm in from the back plate. That leaves room for the 90° HDMI, USB-C and RJ45 plugs.

## Power wiring (USB-C breakout)

1. On the breakout, cut the VCC tracks between the female and male connectors. With a multimeter, female VCC to male VCC must read open.
2. Solder 20 AWG wires: female-side VCC pad → KCD3 → male-side VCC pad.
3. Leave every other pin connected straight through: GND, CC (A5/B5), D+ and D−. CC carries the 5 A handshake.
4. Add a 20 AWG wire between the two GND pads, because the board's tracks are thin.
5. Use a short (10–15 cm) USB-C male→female extension with a 90° plug from the breakout's male plug to the IO board's USB-C port.
   Route it downward from the breakout, under hub 1's left port.
7. The breakout sits at the left end of the back (seen from the front), and the red switch is on the right side wall.
   The two VCC wires are about 20 cm long; run them along the back plate.
6. Use a 27 W (5 V 5 A) USB-C PD adapter, such as the official Raspberry Pi one.

## Keyboard console base (v0.7)

A small base the same width as the PC: the PC sits on the rear deck, and a **KeebDeck Basic** thumb keyboard and a
**USB trackpad module** are screwed into pockets in front, side by side.
**The KeebDeck size is an estimate from photos. The trackpad uses its listing (99.97 × 83 × 12.6 mm including ears, 60 × 45 mm pad); its ear-hole spacing is estimated. Measure both and update `kd_*` / `tp_*` in the config.**

- **Size:** about 223 × 248 × 22 mm (`print_console_base.scad`). It's open underneath with ribs, and fits JLC MJF or a 256 mm home printer.
- **KeebDeck:** sits in a pocket and stands 2 mm above the deck. Four M2 screws go up through the pocket floor into the
  threaded standoffs on its back cover.
- **Trackpad:** sits in a pocket with slots for its ears. Two M3 screws go through the ears, with nuts under the pocket floor.
- **Cables:** both run through holes in the pocket floors, under the deck, and up a Ø14 hole into the PC.
- **Fixing the PC to the base:** the 4 countersunk M3 bolts that hold the PC base to its cover now go up through the console first
  (M3 × 30 instead of M3 × 8).

## USB hubs (v0.7)

Two 65 × 30 mm hubs hang under the cover top. Each IO board USB3 port feeds one hub, giving 6 usable ports:

| Hub | Port | Used for |
|---|---|---|
| Hub 1 (front-left) | USB2, USB3 (face the cable slot) | touchscreen, camera |
| Hub 1 | USB1 | front USB-A |
| Hub 2 (back-middle) | USB1 | front USB-C |
| Hub 2 | USB2, USB3 | KeebDeck, trackpad |
| Hub 1 USB4, Hub 2 USB4 | — | blocked (facing hub 2's plugs / the wall pillar) |
