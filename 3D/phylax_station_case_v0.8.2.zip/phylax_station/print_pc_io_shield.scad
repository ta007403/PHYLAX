// PC I/O shield - flat
// Shape: parts/pc_io_shield.scad    Sizes: phylax_config.scad (section "RJ45 panel-mount jack")
// F5 = quick preview, F6 = full render, F7 = export STL.
// Tip: turn on Design > Automatic Reload and Preview, then edit the config in any editor and save.
include <phylax_config.scad>
include <lib/phylax_common.scad>
include <parts/pc_io_shield.scad>

translate([0,0,-(bp_t - io_shield_t)]) pc_io_shield_local();
