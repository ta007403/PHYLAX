// PC back plate - outside face down
// Shape: parts/pc_back_plate.scad    Sizes: phylax_config.scad (section "Back plate / USB-C breakout")
// F5 = quick preview, F6 = full render, F7 = export STL.
// Tip: turn on Design > Automatic Reload and Preview, then edit the config in any editor and save.
include <phylax_config.scad>
include <lib/phylax_common.scad>
include <parts/pc_back_plate.scad>

translate([0,0,bp_t]) mirror([0,0,1]) pc_back_plate_local();
