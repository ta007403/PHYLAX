// Display clips - print 4
// Shape: parts/mon_display_clips.scad    Sizes: phylax_config.scad (section "Display + clips")
// F5 = quick preview, F6 = full render, F7 = export STL.
// Tip: turn on Design > Automatic Reload and Preview, then edit the config in any editor and save.
include <phylax_config.scad>
include <lib/phylax_common.scad>
include <parts/mon_display_clips.scad>

for (i=[0:3]) translate([i*(clip_w + 14), 0, 0]) mon_display_clip();
