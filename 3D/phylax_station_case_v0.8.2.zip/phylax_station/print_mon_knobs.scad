// Knobs - print 2 (100% infill)
// Shape: parts/mon_knobs.scad    Sizes: phylax_config.scad (section "knob_*")
// F5 = quick preview, F6 = full render, F7 = export STL.
// Tip: turn on Design > Automatic Reload and Preview, then edit the config in any editor and save.
include <phylax_config.scad>
include <lib/phylax_common.scad>
include <parts/mon_knobs.scad>

mon_knob(); translate([knob_d+5,0,0]) mon_knob();
