// PHYLAX Wallet Station - index of all parts (used by assembly.scad).
// Each part lives in its own file in parts/. Shared helpers: lib/phylax_common.scad
include <lib/phylax_common.scad>
include <parts/pc_base.scad>
include <parts/pc_cover.scad>
include <parts/pc_switch_plate.scad>
include <parts/pc_front_panel.scad>
include <parts/pc_speaker_clamp.scad>
include <parts/pc_drive_insert.scad>
include <parts/pc_back_plate.scad>
include <parts/pc_io_shield.scad>
include <parts/badges.scad>
include <parts/mon_bezel.scad>
include <parts/mon_shell.scad>
include <parts/mon_display_clips.scad>
include <parts/mon_knobs.scad>
include <parts/console_base.scad>
include <parts/mocks.scad>
