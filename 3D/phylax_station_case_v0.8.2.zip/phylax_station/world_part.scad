// Exports one part in its ASSEMBLED position (used to refresh stl_world/ for the fast assembly view).
// Normally run by make_world_stls.bat; you don't need to open this file.
include <phylax_config.scad>
include <phylax_parts.scad>
part = "pc_cover";
if (part == "console_base")      console_base();
if (part == "pc_base")           pc_base();
if (part == "pc_cover")          pc_cover();
if (part == "pc_front_panel")    pc_front_panel();
if (part == "pc_speaker_clamp")  pc_speaker_clamp();
if (part == "pc_drive_insert")   pc_drive_insert();
if (part == "pc_back_plate")     pc_back_plate();
if (part == "pc_io_shield")      pc_io_shield();
if (part == "pc_switch_plate")   pc_switch_plate();
if (part == "pc_badge")          pc_badge();
if (part == "mon_bezel")         mon_bezel();
if (part == "mon_badge")         mon_badge();
if (part == "mon_shell")         mon_shell();
if (part == "mon_display_clips") mon_display_clips();
if (part == "mon_knobs")         mon_knobs();
