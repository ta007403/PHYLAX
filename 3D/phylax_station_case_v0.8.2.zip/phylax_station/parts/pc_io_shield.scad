// PHYLAX Wallet Station - PC I/O shield
// Needs: include <../phylax_config.scad> and <../lib/phylax_common.scad> first
// (the print_*.scad files and assembly.scad do this for you).

// I/O shield: holds the RJ45 panel jack (same back-view local frame, sits in the recess)
module pc_io_shield_local() {
    r = shield_rect();
    difference() {
        translate([r[0], r[1], bp_t - io_shield_t]) linear_extrude(io_shield_t) rrect([r[2] - r[0], r[3] - r[1]], 1.5);
        translate([rj45_c[0], rj45_c[1], 0]) linear_extrude(bp_t + 2) rrect_c(rj45_cut, 1);
        for (s = [-1, 1]) translate([rj45_c[0] + s*rj45_ear_spacing/2, rj45_c[1], 0]) cylinder(d = rj45_ear_hole, h = bp_t + 2);
        for (s = shield_screws()) translate([s[0], s[1], bp_t - io_shield_t - 1]) {
            cylinder(d = 2.4, h = 5);
            translate([0, 0, 1 + io_shield_t - 1.0]) cylinder(d1 = 2.4, d2 = 4.4, h = 1.01);
        }
    }
}
module pc_io_shield() back_frame() pc_io_shield_local();
