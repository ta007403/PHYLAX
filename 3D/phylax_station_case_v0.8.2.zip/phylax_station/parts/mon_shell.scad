// PHYLAX Wallet Station - monitor rear shell
// Needs: include <../phylax_config.scad> and <../lib/phylax_common.scad> first
// (the print_*.scad files and assembly.scad do this for you).

// =====================================================================
//  MONITOR REAR SHELL  (local: front opening z = 0, back z = -m_L)
// =====================================================================
module mon_shell_body(o) {
    bw = m_W - 2*m_taper_side; bh = m_H - m_taper_top;
    hull() {
        translate([o, o, -m_collar]) linear_extrude(m_collar + (o > 0 ? 1 : 0))
            rrect([m_W - 2*o, m_H - 2*o], max(1, m_corner_r - o));
        translate([m_taper_side + o, o, -m_L + o]) linear_extrude(0.01)
            rrect([bw - 2*o, bh - 2*o], max(1, m_back_r - o));
    }
}

module mon_shell_local() {
    difference() {
        union() {
            difference() { mon_shell_body(0); mon_shell_body(m_wall); }
            for (b = m_boss_pos)
                translate([b[0], 0, -(b[1] - m_bd)]) rotate([-90, 0, 0]) cylinder(d = m_boss_d, h = m_wall + 6);
        }
        for (b = m_boss_pos)
            translate([b[0], -0.01, -(b[1] - m_bd)]) rotate([-90, 0, 0]) cylinder(d = m3_insert, h = m3_insert_depth);
        // cable pass-through
        translate([cable_slot_pos[0], -1, -(cable_slot_pos[1] - m_bd)]) rotate([-90, 0, 0])
            linear_extrude(m_wall + 2) rrect_c(cable_slot, 3);
        // side screws (countersunk)
        for (y = m_side_screw_y) {
            translate([-1, y, -m_lip/2]) rotate([0, 90, 0]) { cylinder(d = m3_clear, h = m_wall + 2); cylinder(d1 = 6.6 + 2, d2 = m3_clear, h = 1 + (8.6 - m3_clear)/2); }
            translate([m_W + 1, y, -m_lip/2]) rotate([0, -90, 0]) { cylinder(d = m3_clear, h = m_wall + 2); cylinder(d1 = 6.6 + 2, d2 = m3_clear, h = 1 + (8.6 - m3_clear)/2); }
        }
        // back vents
        bh = m_H - m_taper_top;
        for (i = [-4:4])
            translate([m_W/2 + i*10, bh*0.45, -m_L - 1]) linear_extrude(m_wall + 2) vslot(bh*0.4, 3);
    }
}
module mon_shell() mon_frame() mon_shell_local();
