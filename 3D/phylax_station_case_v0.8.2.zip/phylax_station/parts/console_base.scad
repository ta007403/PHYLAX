// PHYLAX Wallet Station - keyboard console base
// Needs: include <../phylax_config.scad> and <../lib/phylax_common.scad> first
// (the print_*.scad files and assembly.scad do this for you).

// =====================================================================
//  KEYBOARD CONSOLE BASE  (world coords, under the PC: z from -cb_H to 0)
// =====================================================================
module console_body() hull() {
    translate([cb_x0, cb_y0, -cb_H]) cube([cb_W, cb_D, cb_H - cb_chamfer]);
    translate([cb_x0 + cb_chamfer, cb_y0 + cb_chamfer, -cb_H]) cube([cb_W - 2*cb_chamfer, cb_D - 2*cb_chamfer, cb_H]);
}
module console_base() {
    difference() {
        union() {
            difference() {
                console_body();
                translate([cb_x0 + cb_wall, cb_y0 + cb_wall, -cb_H - 1]) cube([cb_W - 2*cb_wall, cb_D - 2*cb_wall, cb_H - cb_deck + 1]);
            }
            // keyboard tray
            translate([kd_p0[0] - cb_wall, kd_p0[1] - cb_wall, -kd_depth - cb_floor])
                linear_extrude(kd_depth + cb_floor + 0.01) rrect(kd_pocket + [2*cb_wall, 2*cb_wall], 3 + cb_wall);
            // trackpad tray
            translate([tp_c[0], tp_c[1], -tp_depth - cb_floor]) linear_extrude(tp_depth + cb_floor + 0.01)
                offset(r = cb_wall) tp_pocket_2d();
            // ribs under the PC deck
            for (x = [pc_W/2 - 80 : 40 : pc_W/2 + 80])
                translate([x - cb_rib/2, -cb_gap + cb_wall, -cb_H]) cube([cb_rib, pc_D + cb_gap - 2*cb_wall, cb_H - cb_deck + 0.01]);
            for (y = [40, 100])
                translate([cb_x0 + cb_wall, y - cb_rib/2, -cb_H]) cube([cb_W - 2*cb_wall, cb_rib, cb_H - cb_deck + 0.01]);
            // bolt bosses under the PC pillars + cable collar
            for (p = pillar_pos) translate([p[0], p[1], -cb_H]) cylinder(d = 10, h = cb_H - cb_deck + 0.01);
            translate([kb_cable_hole[0], kb_cable_hole[1], -cb_H]) cylinder(d = kb_cable_hole_d + 4, h = cb_H - cb_deck + 0.01);
        }
        // pockets
        translate([kd_p0[0], kd_p0[1], -kd_depth]) linear_extrude(cb_H) rrect(kd_pocket, 3);
        translate([tp_c[0], tp_c[1], -tp_depth]) linear_extrude(cb_H) tp_pocket_2d();
        // keyboard screws: M2 from below into the KeebDeck's back-cover standoffs
        for (h = kd_hole_pos()) translate([h[0], h[1], -kd_depth - cb_floor - 1]) cylinder(d = 2.4, h = cb_floor + 2);
        // trackpad ear screws: M3 from the top through the ears, nut underneath
        for (s = [-1, 1]) translate([tp_c[0] + s*tp_ear_spacing/2, tp_c[1], -tp_depth - cb_floor - 1]) cylinder(d = tp_ear_hole, h = cb_floor + 2);
        // cable holes in both pocket floors, into the hollow under the deck
        translate([kd_p0[0] + kd_pocket[0]/2, kd_p0[1] + kd_pocket[1] - 10, -kd_depth - cb_floor - 1]) cylinder(d = 12, h = cb_floor + 2);
        translate([tp_c[0] + tp_body[0]/2 - 10, tp_c[1], -tp_depth - cb_floor - 1]) cylinder(d = 12, h = cb_floor + 2);
        // rib cut-outs for the cables
        for (x = [pc_W/2 - 80 : 40 : pc_W/2 + 80]) translate([x - 2, 0, -cb_H - 1]) cube([4, pc_D - cb_wall - 1, 11]);   // stays inside the back wall
        for (y = [40, 100]) translate([cb_x0 + cb_wall + 8, y - 2, -cb_H - 1]) cube([cb_W - 2*cb_wall - 16, 4, 11]);
        // countersunk M3 bolts up into the PC pillars
        for (p = pillar_pos) translate([p[0], p[1], -cb_H - 0.01]) {
            cylinder(d = m3_clear, h = cb_H + 1);
            cylinder(d1 = 6.6 + 2, d2 = m3_clear, h = (8.6 - m3_clear)/2);
        }
        translate([kb_cable_hole[0], kb_cable_hole[1], -cb_H - 1]) cylinder(d = kb_cable_hole_d, h = cb_H + 2);
    }
}
