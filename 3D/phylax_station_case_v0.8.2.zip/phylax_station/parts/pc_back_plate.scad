// PHYLAX Wallet Station - PC back plate
// Needs: include <../phylax_config.scad> and <../lib/phylax_common.scad> first
// (the print_*.scad files and assembly.scad do this for you).

// =====================================================================
//  PC BACK PLATE  (local: seen from behind, x across, y up, outside face at z = bp_t)
// =====================================================================
module bo_shelf() {
    y_top = bo_pcb_y0() - bo_post_h;                 // shelf top surface
    z0 = bo_pcb_z1() - bo_pcb[1] - 4;                 // shelf front end
    w = bo_shelf_w;
    // shelf
    translate([usbc_in_pos[0] - w/2, y_top - bo_shelf_t, z0]) cube([w, bo_shelf_t, -z0 + 0.01]);
    // posts
    for (h = bo_hole_pos()) translate([h[0], y_top - 0.01, h[2]]) rotate([-90, 0, 0]) cylinder(d = bo_post_d, h = bo_post_h + 0.01);
    // two gussets back to the plate
    for (sx = [-1, 1]) translate([usbc_in_pos[0] + sx*(w/2 - 1), 0, 0])
        hull() {
            translate([-1, y_top - bo_shelf_t, z0]) cube([2, bo_shelf_t, 0.01]);
            translate([-1, y_top - bo_shelf_t - 12, -0.01]) cube([2, 12 + bo_shelf_t, 0.01]);
        }
}
module pc_back_plate_local() {
    r = shield_rect();
    difference() {
        union() {
            cube([panel_w, panel_h, bp_t]);
            for (s = shield_screws()) translate([s[0], s[1], -5]) cylinder(d = 5, h = 5.01);
            bo_shelf();
        }
        // window behind the shield + shield recess
        translate([rj45_c[0], rj45_c[1], -1]) linear_extrude(bp_t + 2) rrect_c(io_win, 2);
        translate([r[0] - clr, r[1] - clr, bp_t - io_shield_t]) cube([r[2] - r[0] + 2*clr, r[3] - r[1] + 2*clr, 2]);
        for (s = shield_screws()) translate([s[0], s[1], -6]) cylinder(d = m2_tap, h = 12);
        // USB-C power inlet
        translate([usbc_in_pos[0], usbc_in_pos[1], -1]) linear_extrude(bp_t + 2) rrect_c(usbc_open, 1.6);
        // breakout screw pilots (from the shelf side)
        for (h = bo_hole_pos()) translate([h[0], h[1] - bo_post_h - bo_pcb[2] - 1, h[2]]) rotate([-90, 0, 0]) cylinder(d = m2_tap, h = bo_post_h + 1.5);
        // vents
        for (x = [bp_vent_x0 : bp_vent_pitch : bp_vent_x1])
            translate([x, bp_vent_y0, -1]) linear_extrude(bp_t + 2) vslot(bp_vent_h, bp_vent_w);
    }
}
module pc_back_plate() back_frame() pc_back_plate_local();
