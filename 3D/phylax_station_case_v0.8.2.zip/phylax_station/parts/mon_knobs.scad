// PHYLAX Wallet Station - knobs
// Needs: include <../phylax_config.scad> and <../lib/phylax_common.scad> first
// (the print_*.scad files and assembly.scad do this for you).

// =====================================================================
//  KNOB  (2x)
// =====================================================================
module mon_knob() {
    difference() {
        union() {
            cylinder(d = knob_d, h = knob_h - 1);
            translate([0, 0, knob_h - 1]) cylinder(d1 = knob_d, d2 = knob_d - 2, h = 1);
        }
        for (a = [0:15:359]) rotate([0, 0, a + 3.75]) translate([knob_d/2 + 0.2, 0, -1]) cylinder(d = 1.4, h = knob_h + 2, $fn = 12);
        // D-shaft bore
        translate([0, 0, -0.01]) intersection() {
            cylinder(d = knob_shaft + 0.3, h = knob_h - 2);
            translate([-(knob_shaft + 1)/2, -(knob_shaft + 1)/2 + (knob_shaft - knob_shaft_flat) + 0.15, 0]) cube([knob_shaft + 1, knob_shaft + 1, knob_h]);
        }
        // pointer groove
        translate([-0.5, 1.5, knob_h - 0.6]) cube([1, knob_d/2 - 2, 1]);
    }
}
module mon_knobs() mon_frame() for (k = knob_pos) translate([k[0], k[1], m_bd]) mon_knob();
