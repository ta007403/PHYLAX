// PHYLAX Wallet Station - monitor bezel
// Needs: include <../phylax_config.scad> and <../lib/phylax_common.scad> first
// (the print_*.scad files and assembly.scad do this for you).

// =====================================================================
//  MONITOR BEZEL  (local: x across, y up, back face z = 0, front z = m_bd)
// =====================================================================
module mon_lip_2d(grow = 0) {
    o = m_wall + clr - grow;
    difference() {
        translate([o, o]) rrect([m_W - 2*o, m_H - 2*o], m_corner_r - o);
        translate([o + m_lip_t, o + m_lip_t]) rrect([m_W - 2*(o + m_lip_t), m_H - 2*(o + m_lip_t)], max(1, m_corner_r - o - m_lip_t));
    }
}

module mon_bezel_local() {
    gx = glass_x0 - dsp_glass_clr/2; gy = glass_y0 - dsp_glass_clr/2;
    gs = dsp_glass + [dsp_glass_clr, dsp_glass_clr];
    lip_in = m_wall + clr + m_lip_t;
    difference() {
        union() {
            difference() {
                chamfer_slab([m_W, m_H], m_bd, m_corner_r, m_chamfer);
                translate([m_bw, m_bw, -0.01]) linear_extrude(m_bd - m_fs + 0.01)
                    rrect([m_W - 2*m_bw, m_H - 2*m_bw], m_corner_r - m_bw);
            }
            // glass locating ring
            translate([0, 0, z_glass_front - 5]) linear_extrude(5.01) difference() {
                translate([gx - 2, gy - 2]) square(gs + [4, 4]);
                translate([gx, gy]) square(gs);
            }
            // display clip posts: solid columns standing on the inside of the front skin,
            // joined to the side wall, from the skin down to the pole-tip plane
            // (long enough for both screws of the L-shaped clip)
            // The part beside the glass runs full height to the front skin; the part that reaches
            // under the glass edge stops just behind the display's back plate.
            for (x = clip_post_x, s = [-1, 1]) {
                left = x < m_W/2;
                g  = left ? glass_x0 - dsp_glass_clr/2 : glass_x0 + dsp_glass[0] + dsp_glass_clr/2;   // glass edge
                xa = left ? m_bw - 0.01 : x - clip_post_d/2;
                xb = left ? x + clip_post_d/2 : m_W - m_bw + 0.01;
                y1 = glass_cy + s*dsp_holes[1]/2;           // first screw
                y2 = y1 + s*clip_leg;                        // second screw, toward the corner
                yl = min(y1, y2) - clip_post_d/2;  yh = abs(y2 - y1) + clip_post_d;
                // full-height column beside the glass
                fx0 = left ? xa : max(xa, g);  fx1 = left ? min(xb, g) : xb;
                translate([fx0, yl, z_tip]) cube([fx1 - fx0, yh, z_glass_front - z_tip + 0.01]);
                // foot under the glass edge
                translate([xa, yl, z_tip]) cube([xb - xa, yh, max(0.5, z_glass_back - 0.5 - z_tip)]);
            }
            // lip into the rear shell
            translate([0, 0, -m_lip]) linear_extrude(m_lip + 0.01) mon_lip_2d();
            // thick perimeter wall: solid from the front skin down to the lip, all the way round
            linear_extrude(m_bd - m_fs + 0.01) difference() {
                translate([m_bw - 0.01, m_bw - 0.01]) rrect([m_W - 2*m_bw + 0.02, m_H - 2*m_bw + 0.02], m_corner_r - m_bw);
                translate([lip_in, lip_in]) rrect([m_W - 2*lip_in, m_H - 2*lip_in], max(1, m_corner_r - lip_in));
            }
            // side screw blocks on the lip
            for (x = [lip_in - 0.01, m_W - lip_in - 4], y = m_side_screw_y)
                translate([x, y - 4, -m_lip]) cube([4.01, 8, m_lip + 0.01]);
            // camera posts
            for (sx = [-1, 1], sy = [-1, 1])
                translate([cam_cx + sx*cam_holes[0]/2, cam_cy + sy*cam_holes[1]/2, z_glass_front - cam_lens_h])
                    cylinder(d = cam_post_d, h = cam_lens_h + 0.01);
            // webs tying the upper camera posts to the top wall
            for (sx = [-1, 1])
                translate([cam_cx + sx*cam_holes[0]/2 - 1, cam_cy + cam_holes[1]/2, max(0, z_glass_front - cam_lens_h)])
                    cube([2, m_H - m_bw - (cam_cy + cam_holes[1]/2) + 0.5, z_glass_front - max(0, z_glass_front - cam_lens_h) + 0.01]);
        }
        // screen window with a bevel (CRT look)
        translate([active_cx, active_cy, z_glass_front - 0.01]) hull() {
            linear_extrude(0.01) rrect_c(dsp_active + [1, 1], m_window_r);
            translate([0, 0, m_fs + 0.02]) linear_extrude(0.01)
                rrect_c(dsp_active + [1 + 2*m_window_bevel, 1 + 2*m_window_bevel], m_window_r + m_window_bevel);
        }
        // clip post pilots
        for (x = clip_post_x, s = [-1, 1], k = [0, 1])
            translate([x, glass_cy + s*dsp_holes[1]/2 + k*s*clip_leg, z_tip - 1]) cylinder(d = m3_tap, h = 8);
        // camera lens window + post pilots
        translate([cam_cx, cam_cy, z_glass_front - 0.01]) cylinder(d1 = cam_lens_d, d2 = cam_lens_d + 2*m_fs, h = m_fs + 0.02);
        for (sx = [-1, 1], sy = [-1, 1])
            translate([cam_cx + sx*cam_holes[0]/2, cam_cy + sy*cam_holes[1]/2, z_glass_front - cam_lens_h - 1]) cylinder(d = m2_tap, h = 8);
        // lip notch behind the camera board
        translate([cam_cx - cam_pcb[0]/2 - 2, m_H - lip_in - 3, -m_lip - 1]) cube([cam_pcb[0] + 4, lip_in + 6, m_lip + 1]);
        // knob holes
        for (k = knob_pos) translate([k[0], k[1], -1]) cylinder(d = knob_hole, h = m_bd + 2);
        // badge recess
        translate([badge_mon_pos[0] - 0.2, badge_mon_pos[1] - 0.2, m_bd - badge_depth])
            cube([badge_mon[0] + 0.4, badge_mon[1] + 0.4, badge_depth + 1]);
        // side screw pilots
        for (y = m_side_screw_y) {
            translate([-1, y, -m_lip/2]) rotate([0, 90, 0]) cylinder(d = m3_tap, h = lip_in + 4);
            translate([m_W + 1, y, -m_lip/2]) rotate([0, -90, 0]) cylinder(d = m3_tap, h = lip_in + 4);
        }
    }
}
module mon_bezel() mon_frame() mon_bezel_local();
