// PHYLAX Wallet Station - display clips
// Needs: include <../phylax_config.scad> and <../lib/phylax_common.scad> first
// (the print_*.scad files and assembly.scad do this for you).

// =====================================================================
//  DISPLAY CLIP  (4x)   local, flat
// =====================================================================
// L-shaped clip. Local layout (bottom-right corner, seen from behind):
//   (0,0)        = hole for the screen's brass pole
//   (len,0)      = first screw into the bezel wall post
//   (len,-leg)   = second screw, further along the wall toward the corner
// All 4 clips are the same part: flip 2 of them over for the other side.
module mon_display_clip() {
    len = clip_post_x[1] - (glass_cx + dsp_holes[0]/2);     // pole -> wall screws
    module slot() hull() for (d = [-clip_slot, clip_slot]) translate([d, 0, -1]) cylinder(d = m3_clear, h = clip_t + 2);
    difference() {
        union() {
            hull() { cylinder(d = clip_w, h = clip_t); translate([len, 0, 0]) cylinder(d = clip_w, h = clip_t); }
            hull() { translate([len, 0, 0]) cylinder(d = clip_w, h = clip_t); translate([len, -clip_leg, 0]) cylinder(d = clip_w, h = clip_t); }
        }
        translate([0, 0, -1]) cylinder(d = m3_clear, h = clip_t + 2);
        translate([len, 0, 0]) slot();
        translate([len, -clip_leg, 0]) slot();
    }
}
// world placement of the 4 clips (for the assembly)
module mon_display_clips() mon_frame()
    for (sx = [-1, 1], sy = [-1, 1])
        translate([glass_cx + sx*dsp_holes[0]/2, glass_cy + sy*dsp_holes[1]/2, z_tip - clip_t])
            scale([sx, -sy, 1]) mon_display_clip();
