// PHYLAX Wallet Station - badges
// Needs: include <../phylax_config.scad> and <../lib/phylax_common.scad> first
// (the print_*.scad files and assembly.scad do this for you).

// PHYLAX badges (the badge() shape itself is in lib/phylax_common.scad)
module pc_badge() front_frame() translate([badge_pc_pos[0], badge_pc_pos[1], fp_t - badge_depth]) badge(badge_pc, 4.6);
module mon_badge() mon_frame() translate([badge_mon_pos[0], badge_mon_pos[1], m_bd - badge_depth]) badge(badge_mon, 6);
