// PHYLAX Wallet Station - PC cover
// Needs: include <../phylax_config.scad> and <../lib/phylax_common.scad> first
// (the print_*.scad files and assembly.scad do this for you).

// =====================================================================
//  PC COVER  (top + both side walls; prints upside down)
// =====================================================================
module pc_cover() {
    hc = pc_H - pc_floor;
    fx = pc_W - pc_wall - sw_frame_t;            // inner face of the switch frame
    difference() {
        union() {
            difference() {
                hull() {
                    translate([0, 0, pc_floor]) cube([pc_W, pc_D, hc - pc_round]);
                    for (x = [pc_round, pc_W - pc_round])
                        translate([x, 0, pc_H - pc_round]) rotate([-90, 0, 0]) cylinder(r = pc_round, h = pc_D);
                }
                translate([pc_wall, -1, pc_floor - 1]) cube([pc_W - 2*pc_wall, pc_D + 2, hc - pc_top + 1]);
            }
            // top ribs
            for (yr = rib_ys())
                translate([pc_wall, yr[0], pc_H - pc_top - rib_h]) cube([pc_W - 2*pc_wall, yr[1] - yr[0], rib_h + 0.01]);
            // side ribs
            for (yr = rib_ys(), x = [pc_wall - 0.01, pc_W - pc_wall - rib_h])
                translate([x, yr[0], pc_floor + rib_h + 0.3])
                    cube([rib_h + 0.01, yr[1] - yr[0], pc_H - pc_top - (pc_floor + rib_h + 0.3) + 0.01]);
            // screw pillars
            for (p = pillar_pos)
                translate([p[0], p[1], pc_floor]) cylinder(d = pillar_d, h = pc_H - pc_top - pc_floor + 0.01);
            // USB hub posts (both hubs hang upside down under the top)
            for (hc = [hub_c, hub2_c], sx = [-1, 1], sy = [-1, 1])
                translate([hc[0] + sx*hub_holes[0]/2, hc[1] + sy*hub_holes[1]/2, pc_H - pc_top - hub_post_h])
                    cylinder(d = hub_post_d, h = hub_post_h + 0.01);
            // switch frame (thickens the right wall around the window)
            translate([fx, sw_y - sw_flange[0]/2, sw_z - sw_flange[1]/2]) cube([sw_frame_t + 0.01, sw_flange[0], sw_flange[1]]);
        }
        // heat-set inserts in the pillars
        for (p = pillar_pos)
            translate([p[0], p[1], pc_floor - 0.01]) cylinder(d = m3_insert, h = m3_insert_depth);
        for (hc = [hub_c, hub2_c], sx = [-1, 1], sy = [-1, 1])
            translate([hc[0] + sx*hub_holes[0]/2, hc[1] + sy*hub_holes[1]/2, pc_H - pc_top - hub_post_h - 1])
                cylinder(d = m25_tap, h = hub_post_h + 1 + pc_top - 1);
        // monitor bolts
        for (b = m_boss_pos)
            translate([mon_origin[0] + b[0], mon_origin[1] + b[1], pc_H - pc_top - 1]) cylinder(d = m3_clear, h = pc_top + 2);
        // cable pass-through
        translate([mon_origin[0] + cable_slot_pos[0], mon_origin[1] + cable_slot_pos[1], pc_H - pc_top - rib_h - 1])
            linear_extrude(pc_top + rib_h + 2) rrect_c(cable_slot + [2, 2], 3);
        // switch window
        translate([fx - 1, sw_y - sw_win[0]/2, sw_z - sw_win[1]/2]) cube([sw_frame_t + pc_wall + 2, sw_win[0], sw_win[1]]);
        // switch plate screw pilots
        for (sy = [-1, 1], sz = [-1, 1])
            translate([fx - 0.01, sw_y + sy*(sw_flange[0]/2 - 3.5), sw_z + sz*(sw_flange[1]/2 - 3.5)])
                rotate([0, 90, 0]) cylinder(d = m2_tap, h = sw_frame_t + 1);
    }
}
