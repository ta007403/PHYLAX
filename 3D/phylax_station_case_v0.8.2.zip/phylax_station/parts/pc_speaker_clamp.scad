// PHYLAX Wallet Station - speaker clamp ring
// Needs: include <../phylax_config.scad> and <../lib/phylax_common.scad> first
// (the print_*.scad files and assembly.scad do this for you).

// =====================================================================
//  SPEAKER CLAMP RING  (front-panel local frame: behind the panel = negative z)
//  Presses the speaker rim (on a foam gasket) into the speaker ring; 2 x M3 into the bosses below the vents.
// =====================================================================
spk_lip = speaker_ring_h - (speaker_gasket + speaker_rim_t) + 0.3;   // how far the inner lip reaches into the ring (0.3 mm squeeze)

module pc_speaker_clamp_local() {
    z0 = -speaker_ring_h;                          // top of the speaker ring / bosses
    od = speaker_d + 4;
    difference() {
        union() {
            // ring + ears
            translate([0, 0, z0 - spk_clamp_t]) linear_extrude(spk_clamp_t) {
                translate(speaker_c) circle(d = od);
                for (e = spk_ears) hull() { translate(speaker_c) circle(d = 14); translate(e) circle(d = spk_boss_d + 1); }
            }
            // inner lip that presses on the speaker rim
            if (spk_lip > 0) translate([speaker_c[0], speaker_c[1], z0 - 0.01])
                linear_extrude(spk_lip + 0.01) difference() { circle(d = speaker_d - 0.4); circle(d = spk_clamp_id); }
        }
        translate([speaker_c[0], speaker_c[1], z0 - spk_clamp_t - 1]) cylinder(d = spk_clamp_id, h = spk_clamp_t + spk_lip + 2);
        for (e = spk_ears) translate([e[0], e[1], z0 - spk_clamp_t - 1]) cylinder(d = m3_clear, h = spk_clamp_t + 2);
    }
}
module pc_speaker_clamp() front_frame() pc_speaker_clamp_local();
