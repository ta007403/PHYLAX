// PHYLAX Wallet Station - PC drive faces
// Needs: include <../phylax_config.scad> and <../lib/phylax_common.scad> first
// (the print_*.scad files and assembly.scad do this for you).

// =====================================================================
//  PC DRIVE INSERT  (two 5.25" drive faces, print in black)
// =====================================================================

module drive_face(x0, x1) {
    difference() {
        translate([x0, dr_fy0, dr_zp - 0.01]) cube([x1 - x0, dr_fy1 - dr_fy0, dr_zf - dr_zp + 0.01]);
        translate([x0 + 2, dr_fy0 + 2, dr_zp - 1]) cube([x1 - x0 - 4, dr_fy1 - dr_fy0 - 4, dr_zf - dr_zp - 1.0]);
    }
}

module pc_drive_insert_local() {
    px0 = bay_x0 - 7; px1 = bay_x1 + 7;
    py0 = bay_y0 - 6; py1 = bay_y1 + 5.5;
    lx0 = bay_x0 + clr; lx1 = dr_mid - 0.3;
    rx0 = dr_mid + 0.3; rx1 = bay_x1 - clr;
    difference() {
        union() {
            translate([px0, py0, dr_zp - dr_pt]) cube([px1 - px0, py1 - py0, dr_pt]);
            drive_face(lx0, lx1);
            drive_face(rx0, rx1);
        }
        // plate screw holes
        for (p = bay_boss_pos()) translate([p[0], p[1], dr_zp - dr_pt - 1]) cylinder(d = 2.8, h = dr_pt + 2);

        // --- left face: "fixed disk" ---
        translate([led_c[0], led_c[1], dr_zp - dr_pt - 1]) cylinder(d = led_d, h = 30);
        for (i = [0:7]) translate([lx0 + 18 + i*4.5, dr_fy0 + 5.4, dr_zf - 0.8]) cube([3, 1.2, 2]);
        translate([lx0 + 3, dr_fy1 - 5, dr_zf - 0.5]) cube([lx1 - lx0 - 6, 0.6, 1]);
        if (front_usba) {
            ac = front_usba_c(lx0, lx1);
            translate([ac[0], ac[1], -20]) linear_extrude(40) rrect_c(front_usba_open, 1);
            for (s = [-1, 1]) translate([ac[0] + s*front_usba_ear_spacing/2, ac[1], -20]) cylinder(d = front_usba_ear_hole, h = 40);
            translate([ac[0], ac[1], dr_zp - dr_pt - 1]) linear_extrude(dr_pt + 2) rrect_c([front_usba_plate[0] + 3, 14], 2);
        }

        // --- right face: floppy drive ---
        fc = [(rx0 + rx1)/2, front_usbc_c[1]];
        translate([fc[0] - 23, fc[1] - 2.2, dr_zf - 1.5]) linear_extrude(2) rrect([46, 4.4], 1);   // slot
        translate([fc[0] + 14, fc[1] - 9, dr_zf - 0.6]) cube([9, 18, 1]);                            // door lever
        if (front_usbc) {
            translate([fc[0], fc[1], -20])
                linear_extrude(40) rrect_c(front_usbc_open, 1.6);
            for (s = [-1, 1]) translate([fc[0] + s*front_usbc_ear_spacing/2, fc[1], -20]) cylinder(d = 2.4, h = 40);
            translate([fc[0], fc[1], dr_zp - dr_pt - 1]) linear_extrude(dr_pt + 2) rrect_c([26, 14], 2);
        }
    }
}
module pc_drive_insert() front_frame() pc_drive_insert_local();
