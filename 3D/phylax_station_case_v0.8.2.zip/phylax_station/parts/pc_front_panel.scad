// PHYLAX Wallet Station - PC front panel
// Needs: include <../phylax_config.scad> and <../lib/phylax_common.scad> first
// (the print_*.scad files and assembly.scad do this for you).

// =====================================================================
//  PC FRONT PANEL  (local: x across, y up, front face at z = fp_t)
// =====================================================================

module pc_front_panel_local() {
    difference() {
        union() {
            cube([panel_w, panel_h, fp_t]);
            // speaker ring
            translate([speaker_c[0], speaker_c[1], -speaker_ring_h]) difference() {
                cylinder(d = speaker_d + 4, h = speaker_ring_h + 0.01);
                translate([0, 0, -1]) cylinder(d = speaker_d + speaker_clr, h = speaker_ring_h + 2);
            }
            for (p = bay_boss_pos())
                translate([p[0], p[1], -bay_boss_h]) cylinder(d = bay_boss_d, h = bay_boss_h + 0.01);
            // speaker clamp bosses (same height as the speaker ring)
            for (e = spk_ears) translate([e[0], e[1], -speaker_ring_h]) cylinder(d = spk_boss_d, h = speaker_ring_h + 0.01);
        }
        // vent slots (speaker grille)
        for (i = [0:fp_vent_n - 1])
            translate([fp_vent_x0 + i*fp_vent_pitch + fp_vent_w/2, fp_vent_y0, -1])
                linear_extrude(fp_t + 2) vslot(fp_vent_h, fp_vent_w);
        // badge recess
        translate([badge_pc_pos[0] - 0.2, badge_pc_pos[1] - 0.2, fp_t - badge_depth])
            cube([badge_pc[0] + 0.4, badge_pc[1] + 0.4, badge_depth + 1]);
        // drive bay opening
        translate([bay_x0, bay_y0, -1]) linear_extrude(fp_t + 2) rrect([bay_x1 - bay_x0, bay_y1 - bay_y0], 1);
        // speaker clamp pilots (stop short of the badge recess in front)
        for (e = spk_ears) translate([e[0], e[1], -speaker_ring_h - 1]) cylinder(d = m3_tap, h = speaker_ring_h + 1 + fp_t - badge_depth - 1.5);
        // boss pilots
        for (p = bay_boss_pos())
            translate([p[0], p[1], -bay_boss_h - 1]) cylinder(d = m25_tap, h = bay_boss_h + fp_t - 1.5);
    }
}
module pc_front_panel() front_frame() pc_front_panel_local();
