// PHYLAX Wallet Station - electronics mock-ups (not printed)
// Needs: include <../phylax_config.scad> and <../lib/phylax_common.scad> first
// (the print_*.scad files and assembly.scad do this for you).

// =====================================================================
//  MOCK-UPS (not printed) for checking fit in the assembly
// =====================================================================
module mock_io_board() {
    translate([io_x0, io_y0, io_z0]) {
        color("darkgreen") cube([io_L, io_W, io_t]);
        // CM5 sits between drawing x 72..127, y 36..90  ->  board coords x 33..88, y 0..54
        color("silver") translate([33, 2, io_t]) cube([55, 40, 4.5]);            // CM5 (approx)
        color("dimgray") translate([38, 5, io_t + 4.5]) cube([45, 34, 9]);       // cooler (approx)
    }
    // the ports left open in the shield
    for (p = io_ports_drawing) color("silver")
        translate([io_x0 + io_L - p[1] - p[2]/2, io_y1 - 20, io_ztop]) cube([p[2], 21.5, p[3]]);
}
module mock_display() mon_frame() {
    color("black") translate([glass_x0, glass_y0, z_glass_front - dsp_panel_t]) cube([dsp_glass[0], dsp_glass[1], dsp_panel_t]);
    color("midnightblue") translate([active_cx - dsp_active[0]/2, active_cy - dsp_active[1]/2, z_glass_front - 0.1]) cube([dsp_active[0], dsp_active[1], 0.2]);
    color("dimgray") translate([glass_x0 + 45, glass_y0 + 10, z_tip + 1.5]) cube([70, 75, 4]);   // driver board (approx, between the poles)
    color("gold") for (sx = [-1, 1], sy = [-1, 1])
        translate([glass_cx + sx*dsp_holes[0]/2, glass_cy + sy*dsp_holes[1]/2, z_tip]) cylinder(d = 5, h = dsp_pole_h + 0.01, $fn = 6);
}
module mock_camera() mon_frame() {
    color("black") translate([cam_cx - cam_pcb[0]/2, cam_cy - cam_pcb[1]/2, z_glass_front - cam_lens_h - 1.6]) cube([cam_pcb[0], cam_pcb[1], 1.6]);
    color("dimgray") translate([cam_cx, cam_cy, z_glass_front - cam_lens_h]) cylinder(d = 14, h = cam_lens_h - 0.3);
}
module mock_speaker() front_frame() color("dimgray") translate([speaker_c[0], speaker_c[1], 0]) {
    translate([0, 0, -speaker_gasket - speaker_rim_t]) cylinder(d = speaker_d, h = speaker_rim_t);   // rim
    translate([0, 0, -18]) cylinder(d1 = 18, d2 = 34, h = 18 - speaker_gasket - speaker_rim_t);       // basket + magnet
}
module mock_switch() color("red")
    translate([pc_W - 0.5, sw_y - switch_cut[0]/2, sw_z - switch_cut[1]/2]) cube([2, switch_cut[0], switch_cut[1]]);

module mock_hub() { mock_hub_at(hub_c); mock_hub_at(hub2_c); }
module mock_hub_at(hc) color("royalblue")
    translate([hc[0] - hub_size[0]/2, hc[1] - hub_size[1]/2, pc_H - pc_top - hub_post_h - 1.6]) {
        cube([hub_size[0], hub_size[1], 1.6]);
        color("silver") translate([10, -0.5, -7]) cube([15, 14, 7]);   // USB2 (faces front)
        color("silver") translate([40, -0.5, -7]) cube([15, 14, 7]);   // USB3 (faces front)
        color("silver") translate([-1, 8, -7]) cube([14, 15, 7]);      // USB1 (faces left)
        color("silver") translate([hub_size[0] - 13, 8, -7]) cube([14, 15, 7]);  // USB4 (faces right)
    }
module mock_rj45_jack() back_frame() color("dimgray")
    translate([rj45_c[0] - 10, rj45_c[1] - 10, -32]) cube([20, 20, 32 + bp_t]);
module mock_front_jacks() front_frame() color("dimgray") {
    lx0 = bay_x0 + clr; lx1 = dr_mid - 0.3;
    ac = front_usba_c(lx0, lx1);
    translate([ac[0] - 7, ac[1] - 3.5, -18]) cube([14, 7, 18 + dr_zf - 2]);
    fc = [((dr_mid + 0.3) + (bay_x1 - clr))/2, front_usbc_c[1]];
    translate([fc[0] - 6, fc[1] - 3, -18]) cube([12, 6, 18 + dr_zf - 2]);
}

module mock_usbc_breakout() back_frame() {
    color("green") translate([usbc_in_pos[0] - bo_pcb[0]/2, bo_pcb_y0(), bo_pcb_z1() - bo_pcb[1]]) cube([bo_pcb[0], bo_pcb[2], bo_pcb[1]]);
    color("silver") translate([usbc_in_pos[0] - 4.5, usbc_in_pos[1] - 1.6, bo_pcb_z1() - 0.01]) cube([9, 3.2, bo_socket_out]);
    color("silver") translate([usbc_in_pos[0] - 4.2, usbc_in_pos[1] - 1.3, bo_pcb_z1() - bo_pcb[1] - 11.4]) cube([8.4, 2.6, 11.41]);
}


module mock_keyboard() {
    color([0.1,0.1,0.1]) translate([kd_p0[0] + cb_part_clr, kd_p0[1] + cb_part_clr, -kd_depth]) cube([kd_size[0], kd_size[1], kd_size[2] - 2]);
    color([0.25,0.25,0.25]) for (r = [0:5], c = [0:9])
        translate([kd_p0[0] + cb_part_clr + 7 + c*8.6, kd_p0[1] + cb_part_clr + 8 + r*10.2, -kd_depth + kd_size[2] - 2.01]) cube([6.5, 7.5, 2]);
}
module mock_trackpad() translate([tp_c[0], tp_c[1], -tp_depth]) {
    color([0.12,0.12,0.12]) translate([-tp_body[0]/2, -tp_body[1]/2, 0]) cube([tp_body[0], tp_body[1], tp_body[2]]);
    color([0.12,0.12,0.12]) translate([-tp_span/2, -tp_ear[1]/2, 0]) cube([tp_span, tp_ear[1], 3]);
    color([0.2,0.2,0.22]) translate([-30, -tp_body[1]/2 + 30, tp_body[2] - 0.5]) cube([60, 45, 0.6]);          // 60 x 45 touch pad
    color([0.2,0.2,0.22]) for (s = [-1, 1]) translate([s*17 - 11, -tp_body[1]/2 + 9, tp_body[2] - 0.5]) cube([22, 10, 0.6]);  // buttons
}

module mock_amp() color("royalblue")
    translate([amp_c[0] - amp_size[0]/2, amp_c[1] - amp_size[1]/2, pc_floor + amp_post_h]) {
        cube([amp_size[0], amp_size[1], 1.6]);
        color("lime") translate([5, amp_size[1] - 8, 1.6]) cube([8, 6, 6]);      // speaker terminal
    }
