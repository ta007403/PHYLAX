// PHYLAX Wallet Station - PC base
// Needs: include <../phylax_config.scad> and <../lib/phylax_common.scad> first
// (the print_*.scad files and assembly.scad do this for you).

// =====================================================================
//  PC BASE
// =====================================================================
module pc_base() {
    difference() {
        union() {
            hull() {
                translate([1, 1, 0]) cube([pc_W - 2, pc_D - 2, pc_floor]);
                translate([0, 0, 1]) cube([pc_W, pc_D, pc_floor - 1]);
            }
            // panel ribs
            for (yr = rib_ys())
                translate([pc_wall, yr[0], pc_floor - 0.01]) cube([pc_W - 2*pc_wall, yr[1] - yr[0], rib_h + 0.01]);
            // MAX98357A amp posts
            for (sx = [-1, 1]) translate([amp_c[0] + sx*amp_holes/2, amp_c[1] + amp_size[1]/2 - amp_hole_edge, pc_floor - 0.01])
                cylinder(d = amp_post_d, h = amp_post_h + 0.01);
            // IO board standoffs
            for (h = io_holes)
                translate([io_x0 + h[0], io_y0 + h[1], pc_floor - 0.01]) cylinder(d = io_standoff_d, h = io_standoff_h + 0.01);
        }
        // countersunk M3 screws up into the cover pillars
        for (p = pillar_pos) translate([p[0], p[1], -1]) {
            cylinder(d = m3_clear, h = pc_floor + 2);
            cylinder(d1 = 6.6 + 2, d2 = m3_clear, h = 1 + (6.6 + 2 - m3_clear)/2);
        }
        for (sx = [-1, 1]) translate([amp_c[0] + sx*amp_holes/2, amp_c[1] + amp_size[1]/2 - amp_hole_edge, 1]) cylinder(d = m25_tap, h = pc_floor + amp_post_h);
        // standoff pilot holes
        for (h = io_holes)
            translate([io_x0 + h[0], io_y0 + h[1], 1]) cylinder(d = m25_tap, h = pc_floor + io_standoff_h);
        // vents under the board
        // vents under the CM5 (board coords x 33..88, y 0..54)
        for (i = [0:6])
            translate([io_x0 + 35 + i*9, io_y0 + 4, -1]) linear_extrude(pc_floor + 2) vslot(50, 3);
        // rubber feet recesses
        for (x = [foot_inset, pc_W - foot_inset], y = [foot_inset, pc_D - foot_inset])
            translate([x, y, -0.01]) cylinder(d = foot_d, h = foot_depth);
        // keyboard cable hole (from the console base below)
        translate([kb_cable_hole[0], kb_cable_hole[1], -1]) cylinder(d = kb_cable_hole_d, h = pc_floor + rib_h + 2);
    }
}
