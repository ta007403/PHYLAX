// PHYLAX Wallet Station - PC switch plate
// Needs: include <../phylax_config.scad> and <../lib/phylax_common.scad> first
// (the print_*.scad files and assembly.scad do this for you).

// =====================================================================
//  PC SWITCH PLATE  (KCD3 rocker, right side)
// =====================================================================
module pc_switch_plate() {
    fx = pc_W - pc_wall - sw_frame_t;
    pt = sw_frame_t + pc_wall;                      // plug depth = frame + wall
    difference() {
        union() {
            translate([fx - 2, sw_y - sw_flange[0]/2, sw_z - sw_flange[1]/2]) cube([2, sw_flange[0], sw_flange[1]]);
            translate([fx - 0.01, sw_y - sw_win[0]/2 + clr, sw_z - sw_win[1]/2 + clr]) cube([pt + 0.01, sw_win[0] - 2*clr, sw_win[1] - 2*clr]);
        }
        // switch cutout
        translate([fx - 3, sw_y - switch_cut[0]/2, sw_z - switch_cut[1]/2]) cube([pt + 4, switch_cut[0], switch_cut[1]]);
        // pocket from inside so the clips see switch_panel_t
        translate([fx - 3, sw_y - switch_cut[0]/2 - 2, sw_z - switch_cut[1]/2 - 2])
            cube([3 + pt - switch_panel_t, switch_cut[0] + 4, switch_cut[1] + 4]);
        for (sy = [-1, 1], sz = [-1, 1])
            translate([fx - 3, sw_y + sy*(sw_flange[0]/2 - 3.5), sw_z + sz*(sw_flange[1]/2 - 3.5)])
                rotate([0, 90, 0]) cylinder(d = 2.4, h = 4);
    }
}
