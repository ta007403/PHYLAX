// PC switch plate (KCD3) - outside face down
// Shape: parts/pc_switch_plate.scad    Sizes: phylax_config.scad (section "Power switch")
// F5 = quick preview, F6 = full render, F7 = export STL.
// Tip: turn on Design > Automatic Reload and Preview, then edit the config in any editor and save.
include <phylax_config.scad>
include <lib/phylax_common.scad>
include <parts/pc_switch_plate.scad>

translate([0,0,pc_W]) rotate([0,90,0]) pc_switch_plate();
