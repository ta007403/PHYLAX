// =====================================================================
//  PHYLAX Wallet Station - shared parameters
//  Retro IBM 5150/5151-style case for Raspberry Pi CM5 + CM5 IO Board
//  Remix of "Mini IBM PC - working clone" by alendian (Thingiverse 7253482),
//  after designs by giobbino (Giovanni Verrua) and earlier remixers.
//  License: CC BY-SA 4.0 (same as the original)
//
//  Units: mm.  World axes: X = left->right, Y = front->back, Z = up.
//  Values marked  // MEASURE  are best guesses: check them on your parts.
// =====================================================================

$fn = $preview ? 24 : 48;      // lighter circles in preview (F5), full quality for STL export (F6)
clr = 0.3;                 // general fit clearance

// ---------------- Screws / inserts ----------------
m3_clear   = 3.4;          // M3 through-hole
m3_tap     = 2.6;          // M3 self-tapping into plastic
m3_insert  = 4.0;          // M3 heat-set insert hole (check your inserts)
m3_insert_depth = 6;
m25_tap    = 2.2;          // M2.5 self-tapping
m2_tap     = 1.8;          // M2 self-tapping

// =====================================================================
//  PC (system unit)
// =====================================================================
pc_W = 200;  pc_D = 150;  pc_H = 59;
pc_wall  = 3;              // cover side walls
pc_floor = 3;              // base floor
pc_top   = 3;              // cover top
pc_round = 3;              // radius of cover's top long edges

rib_w = 1.6;               // panel-holding ribs
rib_h = 2;
panel_clr = 0.4;

front_recess = 1.5;        // front panel sits this far behind the case edge
fp_t = 6;                  // front panel thickness
back_recess = 1.5;
bp_t = 4;                  // back plate thickness

// derived panel envelope (front + back panels share it)
panel_w  = pc_W - 2*pc_wall - 2*clr;
panel_h  = pc_H - pc_floor - pc_top - 2*clr;
panel_x0 = pc_wall + clr;
panel_z0 = pc_floor + clr;
fp_y0 = front_recess;           // front face of front panel
fp_y1 = front_recess + fp_t;    // back face of front panel
bp_y1 = pc_D - back_recess;     // outside face of back plate
bp_y0 = bp_y1 - bp_t;           // inside face of back plate

// cover screw pillars (heat-set inserts at the bottom, screws from below)
pillar_d = 8;
pillar_pos = [ [pc_wall+3.5, 24], [pc_wall+3.5, pc_D-26],
               [pc_W-pc_wall-3.5, 24], [pc_W-pc_wall-3.5, pc_D-26] ];

// rubber feet recesses in the base
foot_d = 12;  foot_depth = 1;  foot_inset = 14;

// ---------------- CM5 IO Board ----------------
io_L = 160;  io_W = 90;  io_t = 1.6;
io_standoff_h = 8;
io_standoff_d = 6;
// Board coords: origin = board corner at front-left (seen from PC front),
// x along the 160 mm port edge, y toward the port edge (port edge at y = 90).
// From the official drawing (top view, port edge toward you) the 4 main mounting holes are at
// (11, 8), (11, 77), (132.5, 8), (132.5, 77)  [x from the left end, y from the port edge].
// The right-hand pair is not dimensioned on the drawing: CHECK on the board.
// (The 58 x 49 group at x 3.5 / 61.5 is the HAT pattern, not used here.)
io_holes_drawing = [ [11, 8], [11, 77], [132.5, 8], [132.5, 77] ];
io_holes = [ for (h = io_holes_drawing) [io_L - h[0], io_W - h[1]] ];  // -> board coords used here
io_bay = 22;               // gap between port edge and back plate (room for the 90-degree HDMI / USB-C / RJ45 plugs)

io_x0 = pc_W/2 - io_L/2;
io_y1 = bp_y0 - io_bay;    // port edge
io_y0 = io_y1 - io_W;
io_z0 = pc_floor + io_standoff_h;   // underside of board
io_ztop = io_z0 + io_t;             // top surface of board

// Port centres on the drawing (x from the left end, looking at the ports from outside):
//   HDMI0 23, HDMI1 48, RJ45 74, USB3 93, USB-C power 108, USB3 121.25
// Nothing on the board is exposed. Everything is cabled:
//   HDMI0  -> display (90-degree FPC)        USB-C power -> red switch -> back USB-C inlet
//   RJ45   -> RJ45 panel jack (90-degree)    USB3 93     -> USB hub (inside the cover)
//   USB3 121.25 -> keyboard (internal, for the built-in keyboard later)
io_ports_drawing = [ ["RJ45", 74, 16, 13.5] ];   // only used to draw the mock-up: [name, centre x, w, h]
io_lx0 = (panel_x0 + panel_w) - (io_x0 + io_L);   // board's port-edge left end, back-view local x

// RJ45 panel-mount jack, held by the replaceable I/O shield (back-view local coords)
rj45_c       = [64, 27];          // jack centre on the back plate
rj45_cut     = [20.4, 20.0];      // MEASURE: square body of the jack that passes through the shield
rj45_ear_spacing = 28;            // from the product drawing
rj45_ear_hole = 3.4;              // M3 + nut
io_shield_t  = 2.0;
io_shield    = [50, 32];          // shield plate size, centred on rj45_c
io_win       = [40, 26];          // window in the back plate behind the shield (room for the jack ears)

// USB-C power inlet = USB-C pass-through breakout (36 x 20 mm PCB, holes 28 x 14, female + male)
// lying flat on a shelf behind the back plate. The female socket pokes through the back plate;
// the male plug points into the case and a short 90-degree USB-C extension runs to the IO board.
// VCC is cut on the breakout and routed through the red switch.
usbc_in_pos  = [166.7, 38];       // socket centre on the back plate (back-view local coords): left end of the back,
                                  // clear of the RJ45 shield and the corner pillars
usbc_open    = [9.6, 3.8];        // socket opening
bo_pcb       = [36, 20, 1.6];     // breakout PCB: width (across), depth (front-back), thickness
bo_holes     = [28, 14];          // hole spacing (across, front-back)
bo_hole_edge = 2.1;               // MEASURE: hole centre to the socket-side PCB edge
bo_socket_out = 10;               // MEASURE: how far the female socket sticks out past the PCB edge
bo_socket_h  = 1.6;               // MEASURE: socket centre above the PCB top surface
bo_recess    = 0.3;               // socket mouth sits this far inside the back face
bo_shelf_t   = 2.5;  bo_post_h = 5;  bo_post_d = 5;  bo_shelf_w = 38;

// Back plate vent slots
bp_vent_y0 = 34;  bp_vent_h = 14;  bp_vent_w = 2.5;  bp_vent_pitch = 5.5;
bp_vent_x0 = 96;  bp_vent_x1 = 150;

// ---------------- Front panel layout (front-view local coords) ----------------
//   x from the left edge of the panel, y from the bottom of the panel
fp_vent_n = 13; fp_vent_x0 = 8; fp_vent_pitch = 3.6; fp_vent_w = 2;
fp_vent_y0 = 14; fp_vent_h = 30;
speaker_d = 40.5;  speaker_ring_h = 5;     // speaker drawing: 40.5 +/- 0.4 mm, depth 18 mm, magnet 18 mm
speaker_clr = 0.8;                         // ring hole = speaker_d + speaker_clr (fits up to 40.9 mm)
speaker_c = [fp_vent_x0 + ((fp_vent_n-1)*fp_vent_pitch + fp_vent_w)/2, 28];
// speaker clamp ring (2 x M3 into bosses below the vents)
speaker_gasket = 1.5;        // foam gasket between the speaker rim and the panel
speaker_rim_t  = 2.7;        // speaker drawing: rim 2.7 +/- 0.3 mm
spk_clamp_t    = 3;          // clamp ring thickness
spk_clamp_id   = speaker_d - 8;            // clamp presses the rim, clear of the magnet
spk_ears       = [[speaker_c[0] - 19.4, speaker_c[1] - 19.3], [speaker_c[0] + 19.4, speaker_c[1] + 19.3]];  // 2 x M3, exactly opposite
                                           // (bottom-left below the vents, top-right above them)
spk_boss_d     = 6;
badge_pc = [36, 7];  badge_pc_pos = [10, 4];   badge_depth = 1;
bay_x0 = 62;  bay_x1 = panel_w - 8;  bay_y0 = 8;  bay_y1 = 44;   // drive bay opening
bay_boss_d = 7;  bay_boss_h = 4;

// Drive faces (printed black)
drive_face_proud = 1;      // how far the drive faces sit behind the panel front face
led_d = 8.1;               // 5 mm LED in a chrome metal bezel with nut (8 mm panel hole)
front_usbc = true;         // USB-C port for the PHYLAX block stack in the floppy slot
front_usbc_open = [9.6, 3.8];
front_usbc_ear_spacing = 20;   // MEASURE
front_usbc_ears_from_front = true; // screw heads visible in the floppy slot (retro look)
// USB-A panel-mount jack (PCB plate 31.2 x 10.2, holes 3 mm, 25 mm apart) in the left drive face
front_usba = true;
front_usba_open = [14.8, 7.4];     // jack shell opening
front_usba_ear_spacing = 25;
front_usba_ear_hole = 3.2;
front_usba_plate = [31.2, 10.2];

// ---------------- USB hub (65 x 30, holes 3.5 from edges -> 58 x 23) under the cover top ----------------
hub_size  = [65, 30];
hub_holes = [58, 23];
hub_c     = [75, 98];             // world X/Y centre; long side along X, USB2/USB3 face the front
hub_post_h = 5;  hub_post_d = 6;

// ---------------- MAX98357A I2S amp (18 x 19 mm, 2 holes along one edge) on the PC base floor ----------------
amp_size  = [18, 19];
amp_holes = 13.6;            // hole spacing (estimated from the product picture)
amp_hole_edge = 2.0;         // MEASURE: hole centre to the board edge
amp_c     = [68, 24];        // world X/Y centre: behind the front panel, right of the speaker, under the IO board's front edge
amp_post_h = 3;  amp_post_d = 5;

// ---------------- Power switch (right side wall) ----------------
switch_cut = [30.2, 22.2];      // KCD3 rocker panel cutout (MEASURE your switch)
switch_panel_t = 2.0;           // panel thickness the rocker clips want
sw_win = [40, 32];              // window in the cover wall
sw_flange = [48, 40];
sw_y = pc_D - 55;               // window centre (Y)
sw_z = 33;                      // window centre (Z)
sw_frame_t = 4;                 // thickening ring inside the cover wall around the window

// =====================================================================
//  Monitor
// =====================================================================
// Display: HD DISCLB 7inch  CLB7INH  (measured)
//
//   FRONT VIEW (as you look at the screen)          SIDE VIEW (section)
//   +---------------- glass -----------------+       bezel front skin
//   |  top border                            |       ====|=================
//   | +------------------------------------+ |           | glass + LCD panel  <- dsp_panel_t
//   |l|        visible picture             |r|           |___________________ metal back plate
//   |e|          (dsp_active)              |i|             |  |  brass poles  <- dsp_pole_h
//   |f|                                    |g|            clip  clip          <- screwed to the pole tips
//   |t+------------------------------------+h|
//   |  bottom border                         t
//   +----------------------------------------+
dsp_glass  = [164, 100];            // glass outline W x H (measured)
dsp_border = [3.7, 6.4, 4.6, 8.9];  // dark border from the glass edge to the picture: [left, right, top, bottom] (measured)
dsp_active = [dsp_glass[0] - dsp_border[0] - dsp_border[1], dsp_glass[1] - dsp_border[2] - dsp_border[3]];  // -> 153.9 x 86.5
dsp_holes  = [150, 93.5];           // M3 brass pole spacing (measured), centred on the glass
dsp_pole_h = 7.2;                   // brass pole height above the metal back plate (measured)
dsp_panel_t = 9.6;                  // glass front -> metal back plate where the poles stand (measured)
dsp_stack  = dsp_panel_t + dsp_pole_h;   // glass front -> pole tips
dsp_glass_clr = 0.4;

// USB camera module 38 x 32 with M12 lens (AliExpress 1005013295809460)
cam_pcb   = [38, 32];          // horizontal x vertical
cam_holes = [34, 28];          // MEASURE corner hole spacing
cam_lens_d = 12;               // window in the bezel for the lens
cam_lens_h = 19;               // MEASURE: PCB surface -> front of lens (focus changes it)
cam_post_d = 5;

m_side   = 11;                 // bezel border left/right of the glass
m_bottom = 26;                 // bezel border under the glass (knobs + badge)
m_top    = max(18, cam_pcb[1] + 6);   // grows to fit the camera board

m_W = dsp_glass[0] + 2*m_side;
m_H = dsp_glass[1] + m_bottom + m_top;

m_bd = 20;          // bezel depth
m_fs = 2.5;         // bezel front skin
m_bw = 2.5;         // bezel perimeter wall
m_chamfer = 4;      // 45-degree chamfer on the bezel front edge (prints face-down)
m_corner_r = 8;     // corner radius seen from the front
m_window_r = 5;     // screen window corner radius (CRT look)
m_window_bevel = 2.5;

m_lip = 8;          // bezel lip that slides into the rear shell
m_lip_t = 2;

m_L = 100;          // rear shell depth
m_wall = 2.5;
m_collar = m_lip + 3;      // straight section at the front of the shell
m_taper_side = 22;
m_taper_top = 35;
m_back_r = 6;

m_y0 = 8;           // monitor front face sits this far behind the PC front

// knobs (bottom-right).  Hole fits an EC11 encoder / 7 mm pot bushing.
knob_d = 12; knob_h = 9; knob_hole = 7.2; knob_shaft = 6; knob_shaft_flat = 4.5;
knob_pos = [ [m_W - 22, m_bottom/2], [m_W - 42, m_bottom/2] ];

badge_mon = [44, 9];  badge_mon_pos = [14, (m_bottom-9)/2];
badge_text = "PHYLAX";
badge_font = "DejaVu Sans:style=Bold";

// display clips (4x)
clip_w = 9;  clip_t = 3;  clip_post_d = 8;   // clip bar width / thickness; post column size
clip_leg = 11;                 // L-clip: distance between its 2 screws along the wall
clip_slot = 1.5;               // the 2 wall screw holes are slotted +/- this much (tolerance)

// monitor-to-cover bosses (monitor coords: x across, d = depth from monitor front)
m_boss_d = 9;
m_boss_pos = [ [30, m_bd+25], [m_W-30, m_bd+25], [30, m_bd+m_L-22], [m_W-30, m_bd+m_L-22] ];

// cable pass-through (monitor floor + cover top)
cable_slot = [50, 18];
cable_slot_pos = [m_W/2, m_bd + 21];   // centre, monitor coords

// side screws joining rear shell to the bezel lip (front-view y positions)
m_side_screw_y = [50, 105];

// derived monitor geometry
glass_x0 = m_side;  glass_y0 = m_bottom;
glass_cx = glass_x0 + dsp_glass[0]/2;
glass_cy = glass_y0 + dsp_glass[1]/2;
active_cx = glass_x0 + dsp_border[0] + dsp_active[0]/2;   // centre of the visible picture
active_cy = glass_y0 + dsp_border[3] + dsp_active[1]/2;
cam_cx = m_W/2;
cam_cy = glass_y0 + dsp_glass[1] + m_top/2;
z_glass_front = m_bd - m_fs;            // bezel local: glass front face plane
z_tip = z_glass_front - dsp_stack;      // standoff tip plane (may be < 0)
m_lip_in = m_wall + clr + m_lip_t;                 // inner face of the bezel lip (from the outer edge)
clip_post_x = [m_lip_in + clip_w/2 + 0.5, m_W - m_lip_in - clip_w/2 - 0.5];   // wall screws: clips stay inside the lip
z_glass_back = z_glass_front - dsp_panel_t;        // display's metal back plate
mon_origin = [pc_W/2 - m_W/2, m_y0, pc_H];   // monitor front-bottom-left in world

// =====================================================================
//  Keyboard console base: PC at the back, KeebDeck + USB trackpad in front
//  ALL keyboard / trackpad sizes below are ESTIMATES from photos: MEASURE when they arrive.
// =====================================================================
// KeebDeck Basic (Solder Party): wired USB-C, QMK, threaded standoffs on its back cover
kd_size  = [98, 75, 12];          // MEASURE: outline W x D x total thickness
kd_holes = [88, 65];              // MEASURE: back-cover screw spacing (W x D)
kd_proud = 2;                     // how far the keyboard stands above the deck
// USB trackpad module with 2 buttons and 2 mounting ears
tp_body  = [82, 83, 12.6];        // listing: 99.97 x 83 x 12.6 overall (incl. ears), pad 60 x 45. Body width estimated
tp_ear_spacing = 90;              // MEASURE: ear hole centres (estimated from the 99.97 overall width)
tp_ear   = [10, 14];              // span = spacing + 10 = 100 overall; ear tab width 14 (MEASURE)
tp_ear_hole = 3.2;
tp_proud = 2;
// console
cb_part_clr = 0.6;                // gap around each part in its pocket
cb_side  = 6;                     // rim at the left/right edge
cb_mid   = 10;                    // deck between the keyboard and the trackpad
cb_front = 8;                     // rim in front of the pockets
cb_gap   = 6;                     // deck between the pockets and the PC front
cb_H      = 22;
cb_wall   = 3;  cb_deck = 3;  cb_floor = 2.5;  cb_rib = 2;
cb_chamfer = 2;
tp_span  = tp_ear_spacing + tp_ear[0];                       // trackpad width incl. ears
cb_front_w = 2*cb_side + kd_size[0] + cb_mid + tp_span + 4*cb_part_clr;
cb_W = max(pc_W, cb_front_w);
cb_front_d = max(kd_size[1], tp_body[1]) + 2*cb_part_clr;
cb_D = pc_D + cb_gap + cb_front_d + cb_front;
cb_x0 = pc_W/2 - cb_W/2;
cb_y0 = pc_D - cb_D;
// pocket positions (world corner of each pocket)
cb_px0 = pc_W/2 - (kd_size[0] + cb_mid + tp_span + 4*cb_part_clr)/2;
kd_pocket = [kd_size[0] + 2*cb_part_clr, kd_size[1] + 2*cb_part_clr];
kd_p0 = [cb_px0, cb_y0 + cb_front + (cb_front_d - kd_pocket[1])/2];
tp_pocket = [tp_body[0] + 2*cb_part_clr, tp_body[1] + 2*cb_part_clr];
tp_c = [cb_px0 + kd_pocket[0] + cb_mid + (tp_span + 2*cb_part_clr)/2, cb_y0 + cb_front + cb_front_d/2];
kb_cable_hole = [12, 112];        // world X/Y where both cables come up into the PC (left of the IO board)
kb_cable_hole_d = 14;
// second USB hub, under the cover top, back-right
hub2_c = [132.5, 127.5];          // usable: USB1 (left), USB2 + USB3 (front). USB4 faces the wall pillar
                                  // hub 1 usable: USB1, USB2, USB3 (its USB4 points at hub 2's plugs) -> 6 ports total
