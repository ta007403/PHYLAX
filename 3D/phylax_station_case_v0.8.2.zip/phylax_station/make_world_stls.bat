@echo off
rem Refreshes stl_world\ so assembly.scad's fast mode shows your latest config.
rem Run it (double-click) after changing phylax_config.scad. Takes about 1 minute.
set OPENSCAD="C:\Program Files\OpenSCAD\openscad.exe"
if not exist stl_world mkdir stl_world
for %%P in (console_base pc_base pc_cover pc_front_panel pc_speaker_clamp pc_drive_insert pc_back_plate pc_io_shield pc_switch_plate pc_badge mon_bezel mon_badge mon_shell mon_display_clips mon_knobs) do (
  echo Exporting %%P ...
  %OPENSCAD% -o stl_world\%%P.stl -D "part=\"%%P\"" world_part.scad
)
echo Done. Press F5 in assembly.scad.
pause
