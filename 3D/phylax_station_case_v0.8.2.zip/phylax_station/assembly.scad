include <phylax_config.scad>
include <phylax_parts.scad>
// =====================================================================
//  Full assembly
//  mode = "fast": loads the ready-made meshes in stl_world/ -> opens instantly, rotates smoothly.
//                 After changing phylax_config.scad, double-click make_world_stls.bat to refresh them.
//  mode = "live": builds every part from the code, so it always follows the config.
//                 The first F5 takes a while (each part is calculated once), then it rotates smoothly.
// =====================================================================
mode = "fast";
explode = 0;            // > 0 pulls the parts apart (try 40)

show_console = true;
show_pc      = true;
show_cover   = true;    // hide to see inside the PC
show_monitor = true;
show_shell   = true;    // hide to see inside the monitor
show_mocks   = true;    // electronics mock-ups (not printed)

module P(name, c, off = [0, 0, 0]) color(c) translate(off) {
    if (mode == "fast") import(str("stl_world/", name, ".stl"), convexity = 6);
    else render(convexity = 6) children();
}

if (show_console) P("console_base", "ivory", [0, 0, -explode*0.5]) console_base();
if (show_pc) {
    P("pc_base", "ivory") pc_base();
    if (show_cover) P("pc_cover", "ivory", [0, 0, explode]) pc_cover();
    P("pc_front_panel", "ivory", [0, -explode, 0]) pc_front_panel();
    P("pc_speaker_clamp", "dimgray", [0, -explode*0.4, 0]) pc_speaker_clamp();
    P("pc_drive_insert", [0.15, 0.15, 0.15], [0, -explode*0.6, 0]) pc_drive_insert();
    P("pc_back_plate", "ivory", [0, explode, 0]) pc_back_plate();
    P("pc_io_shield", "silver", [0, explode*1.4, 0]) pc_io_shield();
    P("pc_switch_plate", "ivory", [explode, 0, 0]) pc_switch_plate();
    P("pc_badge", "silver", [0, -explode*1.2, 0]) pc_badge();
}
if (show_monitor) translate([0, 0, explode*2]) {
    P("mon_bezel", "ivory", [0, -explode, 0]) mon_bezel();
    P("mon_badge", "silver", [0, -explode*1.2, 0]) mon_badge();
    if (show_shell) P("mon_shell", "ivory", [0, explode, 0]) mon_shell();
    P("mon_display_clips", "white") mon_display_clips();
    P("mon_knobs", [0.2, 0.2, 0.2], [0, -explode*1.3, 0]) mon_knobs();
}
if (show_mocks) {
    if (show_pc) { mock_io_board(); mock_speaker(); mock_switch(); mock_hub(); mock_rj45_jack(); mock_front_jacks(); mock_usbc_breakout(); mock_amp(); }
    if (show_console) translate([0, 0, -explode*0.5]) { mock_keyboard(); mock_trackpad(); }
    if (show_monitor) translate([0, 0, explode*2]) { mock_display(); mock_camera(); }
}
