// PC speaker clamp ring - print flat
// Shape: parts/pc_speaker_clamp.scad    Sizes: phylax_config.scad (section "Front panel layout")
// F5 = quick preview, F6 = full render, F7 = export STL.
// Tip: turn on Design > Automatic Reload and Preview, then edit the config in any editor and save.
include <phylax_config.scad>
include <lib/phylax_common.scad>
include <parts/pc_speaker_clamp.scad>

translate([0, 0, speaker_ring_h + spk_clamp_t]) pc_speaker_clamp_local();
