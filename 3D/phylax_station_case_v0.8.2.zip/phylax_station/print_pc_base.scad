// PC base - print as is, bottom on the bed
// Shape: parts/pc_base.scad    Sizes: phylax_config.scad (section "PC")
// F5 = quick preview, F6 = full render, F7 = export STL.
// Tip: turn on Design > Automatic Reload and Preview, then edit the config in any editor and save.
include <phylax_config.scad>
include <lib/phylax_common.scad>
include <parts/pc_base.scad>

pc_base();
