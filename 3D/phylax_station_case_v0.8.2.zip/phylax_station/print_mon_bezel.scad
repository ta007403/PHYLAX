// Monitor bezel - front face down
// Shape: parts/mon_bezel.scad    Sizes: phylax_config.scad (section "Monitor (+ display, camera, knobs)")
// F5 = quick preview, F6 = full render, F7 = export STL.
// Tip: turn on Design > Automatic Reload and Preview, then edit the config in any editor and save.
include <phylax_config.scad>
include <lib/phylax_common.scad>
include <parts/mon_bezel.scad>

translate([0,0,m_bd]) mirror([0,0,1]) mon_bezel_local();
