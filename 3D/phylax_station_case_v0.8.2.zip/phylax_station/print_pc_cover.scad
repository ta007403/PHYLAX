// PC cover - printed upside down (top on the bed)
// Shape: parts/pc_cover.scad    Sizes: phylax_config.scad (section "PC  (+ Power switch, USB hub, monitor bolt positions)")
// F5 = quick preview, F6 = full render, F7 = export STL.
// Tip: turn on Design > Automatic Reload and Preview, then edit the config in any editor and save.
include <phylax_config.scad>
include <lib/phylax_common.scad>
include <parts/pc_cover.scad>

translate([0,0,pc_H]) mirror([0,0,1]) pc_cover();
